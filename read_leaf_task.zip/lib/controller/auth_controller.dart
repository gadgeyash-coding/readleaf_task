import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../network/api_endponts.dart';
import '../services/shared_pref.dart';

class AuthController extends GetxController {
  RxBool isLoading = false.obs;

  Future<String?> login(String email, String password) async {
    isLoading.value = true;
    // if (email.isEmpty) {
    //   Get.snackbar("Error", "Email is required");
    //   return null;
    // }
    // if (password.isEmpty) {
    //   Get.snackbar("Error", "Password is required");
    //   return null;
    // }
    try {
      var response = await Dio().get(
        ApiEndPoint.login,
        queryParameters: {"email": email, "password": password},
      );
      String token=response.data["xval"].toString();
      await SharedPrefServices.saveToken(token);
      return response.data["xval"];
    }catch (e) {
      // Get.snackbar("Error", e.toString());
      isLoading.value = false;
      return null;
    }
    finally {
      isLoading.value = false;
    }
  }
}
