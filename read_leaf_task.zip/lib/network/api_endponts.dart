class ApiEndPoint{
  static const login="https://api.salesencia.com/LRS/api/Login/login";
  static const productLIst="https://api.salesencia.com/LRS/api/Installation/GetSparePartsData";

}