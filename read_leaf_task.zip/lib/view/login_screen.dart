import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../controller/auth_controller.dart';
import 'home_screen.dart';

class LoginScreen extends StatelessWidget{
  LoginScreen({super.key});
  final AuthController authController=Get.put(AuthController());
  final  emailController=TextEditingController();
  final  passwordController=TextEditingController();

  @override
  Widget build(BuildContext context) {

return Scaffold(
  appBar: AppBar(
    title: Text('Login'),
  ),
  body: Padding(
    padding: const EdgeInsets.all(16.0),
    child: Column(
      children: [
        TextField(
      controller: emailController,
      decoration: const InputDecoration(
        labelText: "Email",
        border: OutlineInputBorder(),
      ),),
        const SizedBox(height: 16,),
        TextField(
          controller: passwordController,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: "Password",
            border: OutlineInputBorder(),
          ),
        ),
const SizedBox(height: 16,),
        Obx(()=>ElevatedButton(onPressed: () async{

          String? token=await authController.login(
            emailController.text.trim(),
            passwordController.text.trim()
          );
          if(token !=null){
            // Get.snackbar("Success", "Login Successful");
            Get.off(()=>HomeScreen(
            ));
          }

        }, child: authController.isLoading.value?const CircularProgressIndicator():const Text('Login'),),
        ),],
    ),
  )
);
  }
  

}